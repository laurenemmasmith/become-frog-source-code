﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Background : MonoBehaviour
{
    public bool isLevel;

    public float speed;
    public float endX;
    private float length;

    public GameObject spawner;
    public float parallaxSpeed;

    void Start()
    {
        length = GetComponent<SpriteRenderer>().bounds.size.x * 3;
        if (isLevel)
        {
            spawner = GameObject.FindGameObjectWithTag("Spawner");
        }
        speed = parallaxSpeed;
    }

    void Update()
    {
        transform.Translate(Vector2.left * speed * Time.deltaTime);

        if (transform.position.x < endX)
        {
            transform.position = new Vector2(transform.position.x + length, transform.position.y);
        }
        if (isLevel)
        {
            speed = parallaxSpeed / spawner.GetComponent<Spawner>().startSpawnGap;
        }
    }
}
