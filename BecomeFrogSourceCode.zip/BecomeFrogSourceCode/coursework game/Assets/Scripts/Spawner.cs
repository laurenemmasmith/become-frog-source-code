﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    public GameObject[] topGaps; //1
    public GameObject[] middleGaps; //2
    public GameObject[] bottomGaps; //3
    private int currentGap = 2;

    private float spawnGap;
    public float startSpawnGap;
    public float decreaseTime;
    public float minTime = 1.5f;

    private void Update()
    {
        // the following ensures there isnt the same gap twice in a row (would be boring)
        if (spawnGap <= 0){
            if(currentGap == 1)
            {
                float nextGap = Random.value;
                if(nextGap > 0.5)
                {
                    SpawnObjects(middleGaps);
                    currentGap = 2;
                }
                else
                {
                    SpawnObjects(bottomGaps);
                    currentGap = 3;
                }
            }
            else if(currentGap == 2)
            {
                float nextGap = Random.value;
                if (nextGap > 0.5)
                {
                    SpawnObjects(topGaps);
                    currentGap = 1;
                }
                else
                {
                    SpawnObjects(bottomGaps);
                    currentGap = 3;
                }
            }
            else if(currentGap == 3)
            {
                float nextGap = Random.value;
                if (nextGap > 0.5)
                {
                    SpawnObjects(topGaps);
                    currentGap = 1;
                }
                else
                {
                    SpawnObjects(middleGaps);
                    currentGap = 2;
                }
            }
        }else{
            spawnGap -= Time.deltaTime;
        }
    }

    private void SpawnObjects(GameObject[] sets)
    {
        int rand = Random.Range(0, sets.Length);
        Instantiate(sets[rand], transform.position, Quaternion.identity);
        spawnGap = startSpawnGap;
        if (startSpawnGap > minTime)
        {
            startSpawnGap -= decreaseTime;
        }
    }
}
