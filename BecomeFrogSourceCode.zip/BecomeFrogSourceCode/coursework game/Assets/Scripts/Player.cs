﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Player : MonoBehaviour
{
    System.DateTime startTime;
    double levelTime;
    double timer;
    private Vector2 targetPos;

    public float currentYLevel;
    public float speed;
    public int growthPoints = 50;
    public float topY;
    public float middleY;
    public float bottomY;

    public Text growthPointsDisplay;
    public Text timerDisplay;
    public Text levelTimeDisplay;
    public GameObject gameOver;
    public GameObject levelComplete;
    public GameObject levelBackground;
    public GameObject stats;
    public GameObject growSound;
    public void Start()
    {
        startTime = System.DateTime.Now;
        currentYLevel = middleY;
        PointsBar.SetHealthBarValue(growthPoints);
        targetPos = transform.position;
    }

    public void Update()
    {
        timer = (System.DateTime.Now - startTime).TotalSeconds;
        timerDisplay.text = timer.ToString("F2");

        PointsBar.SetHealthBarValue(growthPoints);

        growthPointsDisplay.text = "HP: " + growthPoints.ToString();


        if (growthPoints <= 0){
            gameOver.SetActive(true);
            Destroy(gameObject);
        }
        if (growthPoints >= 100){
            levelTime = (System.DateTime.Now - startTime).TotalSeconds;
            levelTimeDisplay.text = "Level Time: " + levelTime.ToString("F2") + " seconds";

            levelComplete.SetActive(true);
            Destroy(gameObject);
            Instantiate(growSound, transform.position, Quaternion.identity);
        }

        transform.position = Vector2.MoveTowards(transform.position, targetPos, speed * Time.deltaTime);

        // controls

        if((Input.GetKeyDown(KeyCode.UpArrow)|| Input.GetKeyDown(KeyCode.W)) && currentYLevel == middleY){
            targetPos = new Vector2(transform.position.x, topY);
            currentYLevel = topY;

        }else if((Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W)) && currentYLevel == bottomY)
        {
            targetPos = new Vector2(transform.position.x, middleY);
            currentYLevel = middleY;

        }else if((Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.S)) && currentYLevel == topY){
            targetPos = new Vector2(transform.position.x, middleY);
            currentYLevel = middleY;

        }else if((Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKeyDown(KeyCode.S)) && currentYLevel == middleY)
        {
            targetPos = new Vector2(transform.position.x, bottomY);
            currentYLevel = bottomY;
        }

        // dev tools

        // reset level
        else if (Input.GetKeyDown(KeyCode.R)){
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
        // toggle noclip
        else if (Input.GetKeyDown(KeyCode.N)){
            GetComponent<PolygonCollider2D>().enabled = (GetComponent<PolygonCollider2D>().enabled) ? false : true;
        }
        // instant level win
        else if (Input.GetKeyDown(KeyCode.L))
        {
            growthPoints = 100;
        }
        // toggle background
        else if (Input.GetKeyDown(KeyCode.B))
        {
            if (levelBackground.activeSelf == true)
            {
                levelBackground.SetActive(false);
            }
            else
            {
                levelBackground.SetActive(true);
            }
        }
        // show stats
        else if (Input.GetKeyDown(KeyCode.X))
        {
            if (stats.activeSelf == true)
            {
                stats.SetActive(false);
            }
            else
            {
                stats.SetActive(true);
            }
        }
        // mute audio
        else if(Input.GetKeyDown(KeyCode.M)){
            if (AudioListener.volume > 0)
            {
                AudioListener.volume = 0f;
            }
            else
            {
                AudioListener.volume = 1f;
            }
        }
    }
}
