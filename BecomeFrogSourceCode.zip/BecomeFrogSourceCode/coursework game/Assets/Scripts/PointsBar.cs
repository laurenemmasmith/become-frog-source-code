﻿using UnityEngine;
using UnityEngine.UI;
 
public class PointsBar : MonoBehaviour
{
    private static Image HealthBarImage;

    public static void SetHealthBarValue(float value)
    {
        if(HealthBarImage != null)
        {
            HealthBarImage.fillAmount = value / 100;
            if (HealthBarImage.fillAmount < .2f)
            {
                SetHealthBarColor(new Color(1f, 0f, 0.18f));
            }
            else if (HealthBarImage.fillAmount < .4f)
            {
                SetHealthBarColor(new Color(1f, 0.74f, 0f));
            }
            else if (HealthBarImage.fillAmount < .6f)
            {
                SetHealthBarColor(new Color(0.399f, 1f, 0f));
            }
            else if (HealthBarImage.fillAmount < .8f)
            {
                SetHealthBarColor(new Color(0f, 1f, 0.09f));
            }
            else
            {
                SetHealthBarColor(new Color(0f, 1f, 0.34f));
            }
        }
        
    }

    public static float GetHealthBarValue()
    {
        return HealthBarImage.fillAmount;
    }

    public static void SetHealthBarColor(Color healthColor)
    {
        HealthBarImage.color = healthColor;
    }

    private void Start()
    {
        HealthBarImage = GetComponent<Image>();
    }
}