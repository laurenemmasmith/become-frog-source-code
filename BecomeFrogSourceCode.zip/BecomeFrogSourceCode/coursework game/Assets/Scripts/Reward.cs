﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Reward : MonoBehaviour
{
    public int reward;
    private float speed;
    public float minSpeed;
    public float maxSpeed;
    public GameObject hitSound;

    public GameObject effect;
    public Shake shake;
    public GameObject spawner;

    void Start()
    {
        shake = GameObject.FindGameObjectWithTag("ShakeCam").GetComponent<Shake>();
        spawner = GameObject.FindGameObjectWithTag("Spawner");
        speed = (Random.Range(minSpeed, maxSpeed) / (spawner.GetComponent<Spawner>().startSpawnGap)) * (spawner.GetComponent<Spawner>().startSpawnGap + 0.03f);
    }

    private void Update()
    {
        transform.Translate(Vector2.left * speed * Time.deltaTime);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            Instantiate(hitSound, transform.position, Quaternion.identity);

            shake.CamShake();

            Vector2 effectPos = new Vector2(1, other.GetComponent<Player>().currentYLevel);
            Instantiate(effect, effectPos, Quaternion.identity);

            other.GetComponent<Player>().growthPoints += reward;

            Destroy(gameObject);
        }
    }
}