﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameStart : MonoBehaviour
{
    public string nextLevel;
    public string prevLevel;
    public void NextScene()
    {
        SceneManager.LoadScene(nextLevel);
    }
    public void Restart(){
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
    public void PreviousScene()
    {
        SceneManager.LoadScene(prevLevel);
    }
}