﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
// Displays fps, number of objects in scene, and total memory used
// Note: Total memory is mono memory after garbage collection
public class Stats : MonoBehaviour
{
    float fps;
    float monoMemory;
    int objectCount;

    public Text fpsMem;

    void Start()
    {
        StartCoroutine(Recalculate());
    }

    private IEnumerator Recalculate()
    {
        while (true)
        {
            fps = 1.0f / Time.deltaTime;
            monoMemory = System.GC.GetTotalMemory(true) * 0.000125f;
            objectCount = FindObjectsOfType(typeof(MonoBehaviour)).Length;
            yield return new WaitForSeconds(1);
        }
    }

    void Update()
    {
        fpsMem.text = "FPS: " + string.Format("{0:0}", fps)  + "\nScene Objects: " + objectCount + "\nMono Memory: " + string.Format("{0:0}", monoMemory) + "KB";
    }
}
